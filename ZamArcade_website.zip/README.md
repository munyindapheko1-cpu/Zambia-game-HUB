# ZamArcade

A phone-friendly static arcade website featuring:
- Zambian Trivia
- Tap Rush
- Memory Match
- Number Guess
- Reaction Test
- Virtual coins and saved high score
- Ad-space placeholder
- Creator monetization section

## Run it
Open `index.html` in a browser, or upload the folder to a static host.

## Monetization
This starter intentionally does NOT include betting, gambling, cash prizes, or a system that charges players to stake money.

For legitimate monetization, connect an approved advertising network after publishing, seek sponsorships, or add optional paid non-gambling premium content through a payment provider that supports your account and age/eligibility requirements.

Virtual coins in this project have no cash value.
